import urllib,urllib2,sys,re,xbmcplugin
import xbmcgui,xbmcaddon,xbmc
import time,os,urlresolver

local = xbmcaddon.Addon(id='plugin.video.AWEsomeDL')#
sys.path.append( "%s/resources/"%local.getAddonInfo('path') )
from metahandler import metahandlers
from BeautifulSoup import BeautifulSoup
from sqlite3 import dbapi2 as database
from ga import *
from t0mm0.common.net import Net
from t0mm0.common.addon import Addon


addon = Addon('plugin.video.AWEsomeDL', sys.argv)#
datapath = addon.get_profile()
grab = metahandlers.MetaData()
linkback = None
net = Net()
art = xbmc.translatePath(os.path.join(local.getAddonInfo('path'), 'resources', 'art'))
error_logo = os.path.join(addon.get_path(), 'art','redx.jpg')
announce = 'http://jas0npc-xbmc-repository.googlecode.com/svn/trunk/announce/AWE_NOTICE.xml'
cookie_path = os.path.join(datapath, 'cookies')                 
cookie_jar = os.path.join(cookie_path, "cookiejar.lwp")
if os.path.exists(cookie_path) == False:                        
    os.makedirs(cookie_path)
    
BASE_URL = 'http://www.awesomedl.com/'#
print 'AWEsomeDL v2.01'
GA("BETA","V2")

def MAIN():
    addDir(100,BASE_URL,None,'','','Latest Shows','')
    addDir(200,BASE_URL,None,'','','Recommend Top 10 TV Shows','')
    addDir(300,BASE_URL,None,'','','Catagory View','')
    addDir(400,BASE_URL,None,'','','Search','')
    addSpecial('[COLOR yellow]Resolver Settings[/COLOR]','www.nonsense.com','60','')
    addSpecial('[COLOR blue]Having problems, Need help, Click here[/COLOR]','www.nonsense.com','50','')
    setView(None, 'default-view')
    GA("None","Main Menu")
    try:
        link = net.http_GET(announce).content
        ANNOUNCEMENT(link)
    except urllib2.URLError, e:
        pass
    
def INDEX(url,linkback):
    url = url.replace(' ','%20')
    html = GET_HTML(url,linkback)
    if html == None:
        return MAIN()
    html = html.encode('ascii','ignore')
    temp = url+':'
    pattern = 'h2 class="title"><a href="(.+?)/" title.+?img wi'
    pattern +='dth=".+?" src="(.+?)" cla.+?<p>(.+?)</p>'
    r = re.findall(pattern,html,re.DOTALL)
    for url, image, decription in r:
        name = GET_NAME(url)
        addDir(500,url,'tvshow','',decription,name,image)
    if "www.awesomedl.com/search?updated-max=" in html:
        r=re.compile(r"a class='blog-pager-older-link' href='(http://www.awesomedl.com/search\?updated-max=.+?)'").findall(html)
        addDir(None,'',None,url,'','[B][COLOR green] <<<MENU[/COLOR][/B]','')
        addDir(100,r[0],None,url,'',' [B][COLOR yellow]NEXT PAGE>>>[/B][/COLOR]','')
    elif "older-link' title='Older Posts'>Older Posts</a>" in html:
        r = re.findall(r"href='(.+?)'(?= id='Blog1_blog-pager-older-link' title='Older Posts'>Older Posts</a>)",html)
        match = re.findall(r"label/(.+?)[:|?]",temp)
        match = match[0].replace('%20',' ')
        addDir(None,'',None,url,'','[B][COLOR green] <<<MENU[/COLOR][/B]','')
        addDir(100,r[0],None,url,'','[B][COLOR yellow]'+match+': Next Page>>>[/B][/COLOR]','')
    elif "older-link' title='Next Posts'>Next Posts</a>" in html:
        r = re.findall(r"href='(.+?)'(?= id='Blog1_blog-pager-older-link' title='Next Posts'>Next Posts</a>)",html)
        addDir(None,'',None,url,'','[B][COLOR green] <<<MENU[/COLOR][/B]','')
        addDir(100,r[0],None,url,'','[B][COLOR yellow]Next Page>>>[/B][/COLOR]','')
    elif "an> Older posts</a></d" in html:
        r = re.findall(r'eft"><a href="(.+?)"(?= ><span>&laquo)',html)
        addDir(None,'',None,url,'','[B][COLOR green] <<<MENU[/COLOR][/B]','')
        addDir(100,r[0],None,url,'','[B][COLOR yellow]Next Page>>>[/B][/COLOR]','')
        
    GA("INDEX","")
    setView('tvshows', 'episode-view')

def CATAGORY_VIEW(url):
    html = GET_HTML(url,'')
    if html == None:
        return MAIN()
    html = html.replace("/search/label/Site News",'').replace("/search/label/Other",'')
    r = re.findall(r"href='/(search/label/.+?)'>(.+?)</a></li",html)
    for catagory, name in r:
        addDir(100,BASE_URL+catagory,None,'','',name,'')
    GA("CATAGORY_VIEW","")
    
        
def top10(url,linkback):
    html = GET_HTML(url,'')
    if html == None:
        return MAIN()
    html = html.encode("ascii", "ignore")
    r = re.compile(r"<h2 class='title'>Recommend Top 10 TV Shows</h2>(.+?)</div><div class='widget Label'", re.DOTALL).findall(html)
    match = re.compile('a href="(.+?)">(.+?)</a>').findall(str(r))
    for url, name in match:
        name = name.replace(r"\'","'")
        addDir(100,url,'tvshow','latest','',name,'')
    GA("TOP10: ","")
    setView('tvshows', 'tvshow-view')

def VIDEO_LINKS(url,name,types):
    show_name = name
    html = GET_HTML(url,'')
    if html == None:
        return
    r = re.findall(r"<b><u>Watch Online:</b></u>(.+?)<a href='http://www.affbu",html,re.DOTALL)
    r = re.findall(r'href="(.+?)">(.+?)</a>',r[0],re.DOTALL)
    GA(show_name,"VideoLINKS: "+str(len(r)))
    if (len(r) <=3):
        for url, hoster in r:
            name = '[B][COLOR green]'+hoster+': [/B][/COLOR]'+show_name
            addDir(600,url,types,show_name,'',name,'')
    '''BIG THANKS TO BSTRDMKR FOR THE HELP WITH THIS SECTION, HE DID THIS IN SUCH A TIDY
        WAY, MY WAY WAS A LOT BIGGER AND NOT AS TIDY'''
    post_pattern = r"<b><u>Watch Online:</b></u>(.+?)<a href='http://www.affbu"
    for post in re.finditer(post_pattern, html, re.DOTALL|re.M):
        content_pattern = r'/>\W?((?:[\w\.-])+)<br.+?href="(.+?)">(\w+)<.+?href="(.+?)">(\w+)<.+?href="(.+?)">(\w+)<'
        content = re.finditer(content_pattern, post.group(1), re.DOTALL)
    media = []
    for item in content:
        title, link1, host1, link2, host2, link3, host3 = item.groups()
        title = str(title.replace('.',' '))
        media.append((('[B][COLOR green]'+host1+'[/B][/COLOR]', title+'|'+link1), ('[B][COLOR green]'+host2+'[/B][/COLOR]', title+'|'+link2), ('[B][COLOR green]'+host3+'[/B][/COLOR]', title+'|'+link3)))
    for item in media:
        for info_set in item:
            name = "".join(str(info_set)).strip('[]')
            r = name.split('|')
            name = r[0].replace("('",'').replace("', '",' : ').replace("')","")
            url = r[1]
            r = name.split(':')
            show_name = str(r[1].strip())
            addDir(600,url,'episode',show_name,'',name,'')

    
def WATCH_MEDIA(url,types,linkback):
    url = url.replace("')","")
    if 'adf.ly' in url:
        try:
            url = url.replace("')","")
            html = GET_HTML(url,'')
            if html == None:
                return
            r = re.findall(r"var zzz = '(.+?)';\n.+?if\(ea",html,re.M)
            url = r[0]
        except Exception, e:
            print "Failed to retrieve page: %s" %url
            print 'Urllib2 error: '+str(e)
            return
    r = linkback.split('Season')
    types = 'episode'
    infoLabels = GRABMETA(name,types)
    media_url = urlresolver.resolve(url)
    liz=xbmcgui.ListItem(name, iconImage=infoLabels['cover_url'], thumbnailImage=infoLabels['cover_url'])
    liz.setInfo( type="Video", infoLabels={ "Title": linkback} )
    liz.setProperty("IsPlayable","true")
    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    pl.add(str(media_url), liz)
    GA("WATCHING: ",infoLabels['title'])
    xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(pl)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=media_url,isFolder=False,listitem=liz)
    #return

def GET_HTML(url,linkback):
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link = link.decode("utf-8")
        link = link.encode("ascii","ignore")
        return link
    except urllib2.URLError, e:
        xbmc.executebuiltin("XBMC.Notification([B][COLOR red]Connection Error[/B][/COLOR],"+str(e)+",5000,os.path.join(art,'redx.jpg')")
        print 'URLLIB ERROR: '+str(e)
        GA("URLLIB2 ERROR",str(e))
        return

def GET_NAME(url):
    name = str(url).rpartition('/')
    name = str(name[2]).replace('-',' ')
    return name
        

def SEARCH():
    last_search = addon.load_data('search')
    if not last_search: last_search = ''
    search_entered = ''
    keyboard = xbmc.Keyboard(search_entered, 'Search AwesomDL...XBMCHUB.COM')
    last_search = last_search.replace('+',' ')
    keyboard.setDefault(last_search)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()#.replace(' ','+')# sometimes you need to replace spaces with + or %20#
        addon.save_data('search',search_entered)
    if search_entered == None or len(search_entered)<1:
        MENU()
    else:
        url = 'http://www.awesomedl.com/search?q=%s&x=0&y=0'%(search_entered).replace(' ','+')
        GA("None","SEARCH: "+search_entered)
        INDEX(url,'')


def HELP():
    help = SHOWHELP()
    help.doModal()
    GA("None","MODE: SHOWHELP")
    del help

def ANNOUNCEMENT(link):
    GA("None","ANNOUNCEMENT")
    r = re.findall(r'ANNOUNCEMENT ="ON"',link)
    if r:
        popup = TextBox()
        #return
    else:
        r = re.findall(r'<title>(.+?)<Etitle><line1>(.+?)<Eline1><line2>(.+?)<Eline2><line3>(.+?)<Eline3>',link,re.I)
        for title, line1, line2, line3 in r:
            dialog = xbmcgui.Dialog()
            ok = dialog.ok('[B][COLOR red]'+title+'[/B][/COLOR]','[COLOR red]'+line1+'[/COLOR]','[COLOR red]'+line2+'[/COLOR]','[COLOR red]'+line3+'[/COLOR]')
    return

def GRABMETA(name,types):
    type = types
    name = str(name).split('season')
    name = str(name[0]).strip()
    meta = grab.get_meta('tvshow',name,None,None,None,overlay=6)
    infoLabels = {'backdrop_url': meta['backdrop_url']}
    if type == None: infoLabels = {'cover_url': '','title': name}
    
    return infoLabels


class SHOWHELP(xbmcgui.Window):
    def __init__(self):
        self.addControl(xbmcgui.ControlImage(0,0,1280,720,os.path.join(art,'Help.png')))
    def onAction(self, action):
        if action == 92 or action == 10:
            xbmc.Player().stop()
            self.close()

def addDir(mode,url,types,linkback,meta_name,name,iconimage):
    infoLabels = GRABMETA(name,types)
    img = iconimage
    u=sys.argv[0]+"?mode="+str(mode)+"&url="+str(url)+"&types="+str(types)+"&linkback="+str(linkback)+"&meta_name="+str(meta_name)+"&name="+str(name)+"&iconimage="+str(iconimage)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": meta_name} )
    try:
        if types != None:
            liz.setProperty('fanart_image', infoLabels['backdrop_url'])#
    except:
        pass
    if local.getSetting("list_alphabetically") == "true" :
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE)#needs to check on this
    if linkback == 'latest' and local.getSetting("list_alphabetically") == "true":
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_NONE)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addSpecial(name,url,mode,image):
    liz=xbmcgui.ListItem(label = '[B]%s[/B]'%name,iconImage="",thumbnailImage = image)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=sys.argv[0]+"?url=%s&mode=%s&name=%s"%(url,mode,name),isFolder=False,listitem=liz)

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                    params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                    splitparams={}
                    splitparams=pairsofparams[i].split('=')
                    if (len(splitparams))==2:
                            param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
mode=None
url=None
types=None
linkback=None
meta_name=None
name=None
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        meta_name=urllib.unquote_plus(params["meta_name"])
except:
        pass

try:
        linkback=urllib.unquote_plus(params["linkback"])
except:
        pass
try:
        types=urllib.unquote_plus(params["types"])
except:
        pass
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
print '----------------------------------------------------'
print 'Mode: '+str(mode)
print 'URL: '+str(url)
print 'TYPEs: '+str(types)
print 'Linkback: '+str(linkback)
print 'Meta_Name: '+str(meta_name)
print 'Name: '+str(name)
print '----------------------------------------------------'
if mode==None or url==None or len(url)<1:
    MAIN()
elif mode == 50:
    HELP()
elif mode == 60:
    urlresolver.display_settings()
elif mode == 100:
    linkback = 'latest'
    INDEX(url,linkback)
elif mode == 200:
    linkback = 'top10'
    top10(url,linkback)
elif mode == 300:
    CATAGORY_VIEW(url)
elif mode == 400:
    SEARCH()
elif mode == 500:
    VIDEO_LINKS(url,name,types)
elif mode == 600:
    WATCH_MEDIA(url,types,linkback)

addon.end_of_directory()
