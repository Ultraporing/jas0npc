import urllib,urllib2,sys,re,xbmcplugin
import xbmcgui,xbmcaddon,xbmc,base64
import time,datetime,os,urlresolver
#import settings

from t0mm0.common.net import Net
from t0mm0.common.addon import Addon
from BeautifulSoup import BeautifulSoup

net = Net()
addon = Addon('plugin.video.tv-release', sys.argv)
#Addon = xbmcaddon.Addon(id='plugin.video.tv-release')
mode = addon.queries['mode']
play = addon.queries.get('play', None)
url = addon.queries.get('url', None)
linkback = addon.queries.get('linkback', None)

print 'Mode: ' + str(mode)
print 'Play: ' + str(play)
print 'url: ' + str(url)
print 'linkback:' + str(linkback)

def GETTITLES(url):
    print 'GET TITLES URL : '+(url)
    cat = re.compile('http://tv-release.net/category/([a-zA-z/]*)/').findall(url)
    for cat in cat:
        print 'CAT IN URL : '+str(cat)
    html = net.http_GET(url).content
    match=re.compile('''style="text-align:left;">\n<a href="(.+?)".+?<font size="2px">(.+?)</font>''', re.DOTALL).findall(html)
    page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
    for url1, name in match:
        addon.add_directory({'mode': 'getlinks', 'url': url1},{'title': name},img='')
    url = 'http://tv-release.net/category/'+cat+'/page/2/'
    print 'URL IN NEXT PAGE : '+str(url)
    addon.add_directory({'mode': 'NEXTPAGE', 'url': url},{'title': 'Next Page>>'},img='')        
    addon.end_of_directory()

def NEXTPAGE(url):
    match = re.compile('http://tv-release.net/category/([a-zA-z/]*)/page/([0-9])/').findall(url)
    for cat, pageno in match:
        print 'CAT IN URL IN NEXT PAGE : '+str(cat)
        print 'PAGE NO IN NEXT PAGE : '+str(pageno)
    html = net.http_GET(url).content
    match=re.compile('''style="text-align:left;">\n<a href="(.+?)".+?<font size="2px">(.+?)</font>''', re.DOTALL).findall(html)
    for url1, name in match:
        addon.add_directory({'mode': 'getlinks', 'url': url1},{'title': name},img='')
    pageno = int(pageno)+1
    pageno = str(pageno)
    url = 'http://tv-release.net/category/'+cat+'/page/'+pageno+'/'
    print 'URL WITH NEXTPAGE NO : '+str(url)
    addon.add_directory({'mode': 'NEXTPAGE', 'url': url},{'title': 'Next Page>>'},img='')

    addon.end_of_directory()
    

def main():
    print 'Main'
    addon.add_directory({'mode': 'TVSHOWS'}, {'title':'TV Shows'}, img='')
    addon.add_directory({'mode': 'MOVIES'}, {'title':'Movies'}, img='')
    addon.add_directory({'mode': 'SEARCH'}, {'title':'Search'}, img='')
    addon.add_directory({'mode': 'RESOLVERSETTINGS'}, {'title':'Resolver Settings'}, img='')
    addon.end_of_directory()



def SEARCHNP(url):
        url1=re.compile('s=(.+?)&cat').findall(str(url))
        for url1 in url1:
            html = net.http_GET(url).content
            match=re.compile(r':left;">\n<a href="(.+?)/"><b>', re.DOTALL).findall(html)
            page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
            for search in match:
                name=str(search).replace('http://tv-release.net','').replace('/','').replace('-',' ')
                addon.add_directory({'mode': 'getlinks', 'url': search}, {'title': name}, img='')
            if len(page)==1:
                for page in page:
                    nextp=int(page)+1
                    nextp=str(nextp)
                    url='http://tv-release.net/page/'+(nextp)+'/?s='+str(url1)+'&cat'
                    addon.add_directory({'mode': 'searchNP', 'url': url}, {'title': 'Next Page >>'}, img='')
        
        addon.end_of_directory()

def getlinks(url):
    print 'GETLINKS : URL :'+str(url)
    linkback = str(url)
    sources = []
    link  = BeautifulSoup(urllib2.urlopen(url), convertEntities=BeautifulSoup.HTML_ENTITIES)
    sourcff=re.compile(r'<tbody>\n<tr><td class="td_heads">(.+?)</tbody></table>',re.DOTALL|re.IGNORECASE).findall(str(link))
    for hosturl in sourcff:
        urls = re.compile(r'href=".+?//(.+?)/.+?">(htt.+?)</a><br />').findall(hosturl)
        for host, url in urls:
            name = str(url)
            name = re.compile(r'(?<=/)([^/]+?)(?=\.avi|\.mp4|\.mkv)').findall(name)
            if len(name) >=1:
                name = str(name).replace('.',' ')
                host = str(host)+' - '+str(name)
            
            r = re.findall('\.rar[(?:\.html|\.htm)]*',url, re.IGNORECASE)
            if r:
                continue
            try:
                if urlresolver.HostedMediaFile(url=url, title=host):
                    addon.add_directory({'mode': 'play', 'url': url, 'linkback': linkback} , {'title':host})
            except:
                continue
    addon.end_of_directory()

    

if mode == 'main':
    main()

elif mode == 'GETTITLESNP':
    GETTITLES(url)

elif mode == 'searchNP':
    print 'SEARCHNP URL : '+str(url)
    SEARCHNP(url)

elif mode == 'NEXTPAGE':
    NEXTPAGE(url)    
    
elif mode == 'getlinks':
    getlinks(url)

elif mode =='nextpage':
    GETTITLES(url)

elif mode == 'play':
    stream_url = urlresolver.HostedMediaFile(url).resolve()
    if stream_url:
        xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(stream_url)
        addon.add_directory({'mode': 'play', 'url': url}, {'title': 'Play Again'})
    else:
        dialog=xbmcgui.Dialog()
        dialog.ok("SORRY", "     This Source Is Not Playable, Please Choose Another.")
        url = str(linkback)
        getlinks(url)
    addon.end_of_directory()

elif mode =='MOVIES':
    addon.add_directory({'mode': 'MOVIESXVID'}, {'title':'Movies - XVID'}, img='')
    addon.add_directory({'mode': 'MOVIES720'}, {'title':'Movies - 720p'}, img='')
    addon.add_directory({'mode': 'MOVIES480'}, {'title':'Movies - 480p'}, img='')
    dialog = xbmcgui.Dialog()
    dialog.ok("SORRY", "    If No Sources Show, Its Because They are .RAR files\n                               AND WILL NOT STREAM ")
    addon.end_of_directory()

elif mode == 'MOVIESXVID':
    url = 'http://tv-release.net/category/movies/moviesxvid/'
    GETTITLES(url)

elif mode == 'MOVIES720':
    url = 'http://tv-release.net/category/movies/movies720p/'
    GETTITLES(url)

elif mode == 'MOVIES480':
    url = 'http://tv-release.net/category/movies/movies480p/'
    GETTITLES(url)

elif mode == 'TVSHOWS':
    addon.add_directory({'mode': 'TVSHOWSXVID'}, {'title':'TV Shows - XVID'}, img='')
    addon.add_directory({'mode': 'TVSHOWSMP4'}, {'title':'TV Shows - MP4'}, img='')
    addon.add_directory({'mode': 'TVSHOWS720'}, {'title':'TV Shows - 720'}, img='')
    addon.add_directory({'mode': 'TVSHOWS480'}, {'title':'TV Shows - 480'}, img='')
    addon.end_of_directory()

elif mode == 'TVSHOWSXVID':
    url = 'http://tv-release.net/category/tvshows/tvxvid/'
    GETTITLES(url)

elif mode == 'TVSHOWSMP4':
    url = 'http://tv-release.net/category/tvshows/tvmp4/'
    GETTITLES(url)

elif mode == 'TVSHOWS480':
    url = 'http://tv-release.net/category/tvshows/tv480p/'
    GETTITLES(url)

elif mode == 'TVSHOWS720':
    url = 'http://tv-release.net/category/tvshows/tv720p/'
    GETTITLES(url)

elif mode == 'SEARCH':
    search_entered = ''
    keyboard = xbmc.Keyboard(search_entered, 'Search TV-Release...XBMCHUB.COM')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText().replace(' ','+')# sometimes you need to replace spaces with + or %20#
        if search_entered == None or len(search_entered)<1:
            main()
        else:
            url = 'http://tv-release.net/?s=%s&cat='%(search_entered).replace(' ','+')
            SEARCHNP(url)
    

elif mode == 'RESOLVERSETTINGS':
    urlresolver.display_settings()
    
