import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,base64,datetime,os,urlresolver
import time
from t0mm0.common.net import Net
from t0mm0.common.addon import Addon
net = Net()

addon_id = 'plugin.video.tv-release'
addon = Addon('plugin.video.tv-release', sys.argv)
plugin = xbmcaddon.Addon(id=addon_id)

def CATEGORIES():
        addDir('Movies-XviD','http://tv-release.net/category/movies/moviesxvid/',4,'')
        addDir('Movies-720p','http://tv-release.net/category/movies/movies720p/',5,'')
        addDir('Movies-480p','http://tv-release.net/category/movies/movies480p/',6,'')
        addDir('Tv Shows-Xvid','http://tv-release.net/category/tvshows/tvxvid/',7,'')
        addDir('Tv Shows-Mp4','http://tv-release.net/category/tvshows/tvmp4/',8,'')
        addDir('Tv Shows-720p','http://tv-release.net/category/tvshows/tv720p/',9,'')
        addDir('Tv Shows-480p','http://tv-release.net/category/tvshows/tv480p/',10,'')
        #addDir('Tv Shows-tvpacks','http://tv-release.net/category/tvshows/tvpack/',4,'')
        #addDir('Tv Shows-DVD Rips','http://tv-release.net/category/tvshows/tvdvdrip/',4,'')
        addDir('Search','http://tv-release.net/',13,'')
        addDir('Resolver Settings','',15,'')
        
                       
def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('').findall(link)
        for thumbnail,url,name in match:
                addDir(name,url,2,thumbnail)

def VIDEOLINKS(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        #sourcrs=re.compile(''''class="td_heads"><img src="(http://www.tv-release.net/images/rs.png)".+?href='(.+?)'>''').findall(str(link))
        sourcff=re.compile(r'<tr><td class="td_heads">(.+?)</a><br></td></tr>',re.DOTALL).findall(str(link))
        print (sourcff)
        #sourcff=re.compile('class="td_heads"><img src="(http://www.tv-release.net/images/ff.png)"(.+?)</a><br></td></tr><tr><td').findall(link)
        #sourcff=re.compile('''class="td_heads"><img src="(http://www.tv-release.net/images/ff.png)".+?href='(.+?)'>''').findall(str(link))
        #sourc180=re.compile('''class="td_heads"><img src="(http://www.tv-release.net/images/18upload.png)".+?href='(.+?)'>''').findall(str(link))
        #sourcuplo=re.compile('''class="td_heads"><img src="(http://www.tv-release.net/images/uploaded.png)".+?target='_blank' href='(.+?)'>''').findall(str(link))
        #sourcrg=re.compile('''class="td_heads"><img src="(http://www.tv-release.net/images/rapidgator.png)".+?href='(.+?)'>''').findall(str(link))
        #sourcbit=re.compile('''class="td_heads"><img src="(http://www.tv-release.net/images/bitshare.png)".+?href='(.+?)'>''').findall(str(link))
        #sourccro=re.compile('''class="td_heads"><img src="(http://www.tv-release.net/images/crocko.png)".+?href='(.+?)'>''').findall(str(link))
        #sourcms=re.compile('''class="td_heads"><img src="(http://www.tv-release.net/images/megashares.png)".+?href='(.+?)'>''').findall(str(link))
        #try:
        #        for iconimage, hosturl in sourcrs:
        #                name='RapidShare'
        #                media_url=urlresolver.resolve(hosturl)
        #                url= str(media_url)
        #                addLink(name,url,iconimage)
        #except:
        #        pass

        try:
                for  hosturl in sourcff:
                        print (hosturl)
                        name='FileFactory'
                        urls=re.compile("href='(.+?)'>").findall(hosturl)
                        print (urls)
                        for url in urls:
                                sources = []
                                print 'urls-=-=-=-=-=-=-=-=-=-='+(url)
                                hosted_media = urlresolver.HostedMediaFile(url=url)
                                #print 'hm+++++++++++++++++++++++++++++'+(hosted_media)
                                sources.append(hosted_media)
                                name=str(url).replace('http://','').replace('https://','').replace('.com','').replace('www.','')
                                addDir(name,url,16,'')
                                









                                

                        #media_url=urlresolver.resolve(hosturl)
                        #url= str(media_url)
                        #addLink(name,url,iconimage)
        except:
                pass
        #try:
        #        for iconimage, hosturl in sourc180:
        #                name='180Upload'
        #                media_url=urlresolver.resolve(hosturl)
        #                url= str(media_url)
        #                addLink(name,url,iconimage)
        #except:
        #        pass
        #try:
        #        for iconimage, hosturl in sourcuplo:
        #                name='Uploaded'
        #                media_url=urlresolver.resolve(hosturl)
        #                url= str(media_url)
        #                addLink(name,url,iconimage)
        #except:
        #        pass
        #try:
        #        for iconimage, hosturl in sourcrg:
        #                name='Rapidgator'
        #                media_url=urlresolver.resolve(hosturl)
        #                url= str(media_url)
        #                addLink(name,url,iconimage)
        #except:
        #        pass
        #try:
        #        for iconimage, hosturl in sourcbit:
        #                name='BitShare'
        #                media_url=urlresolver.resolve(hosturl)
        #                url= str(media_url)
        #                addLink(name,url,iconimage)
        #except:
        #        pass
        #try:
        #        for iconimage, hosturl in sourccro:
        #                name='Crocko'
        #                media_url=urlresolver.resolve(hosturl)
        #                url= str(media_url)
        #                addLink(name,url,iconimage)
        #except:
        #        pass
        #try:
        #        for iconimage, hosturl in sourcms:
        #                name='Megashares'
        #                media_url=urlresolver.resolve(hosturl)
        #                url= str(media_url)
        #                addLink(name,url,iconimage)
        #except:
        #        pass
        
         
        
def MOVIESXVID(url):
        #html = net.http_GET(url).content
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        #req.add_header('Referer', str(iconimage))
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        html=str(link)
        match=re.compile('''style="text-align:left;">\n<a href="(.+?)".+?<font size="2px">(.+?)</font>''', re.DOTALL).findall(html)
        page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
        for url1, name in match:
                addDir(name,url1,2,'')
        for page in page:
                nextp=int(page)+1
                nextp=str(nextp)
        url='http://tv-release.net/category/movies/moviesxvid/'+'page/'+(nextp)+'/'
        addDir('Next Page >>',url,4,'')

def MOVIES720(url):
        print 'MOVIES720 url================================================'+str(url)
        #html = net.http_GET(url).content
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        #req.add_header('Referer', str(iconimage))
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        html=str(link)
        match=re.compile('''style="text-align:left;">\n<a href="(.+?)".+?<font size="2px">(.+?)</font>''', re.DOTALL).findall(html)
        page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
        for url1, name in match:
                addDir(name,url1,2,'')
        if len(page)==1:
                for page in page:
                        nextp=int(page)+1
                        nextp=str(nextp)
                        url='http://tv-release.net/category/movies/movies720p/'+'page/'+(nextp)+'/'
                        addDir('Next Page >>',url,5,'')

def MOVIES480(url):
        #html = net.http_GET(url).content
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        #req.add_header('Referer', str(iconimage))
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        html=str(link)
        match=re.compile('''style="text-align:left;">\n<a href="(.+?)".+?<font size="2px">(.+?)</font>''', re.DOTALL).findall(html)
        page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
        for url1, name in match:
                addDir(name,url1,2,'')
        if len(page)==1:
                for page in page:
                        nextp=int(page)+1
                        nextp=str(nextp)
                        url='http://tv-release.net/category/movies/movies480p/'+'page/'+(nextp)+'/'
                        print 'URLURLURLURLURLURLURL================================='+str(url)
                        addDir('Next Page >>',url,6,'')

def TVSHOWSXVID(url):
        #html = net.http_GET(url).content
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        #req.add_header('Referer', str(iconimage))
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        html=str(link)
        match=re.compile('''style="text-align:left;">\n<a href="(.+?)".+?<font size="2px">(.+?)</font>''', re.DOTALL).findall(html)
        page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
        for url1, name in match:
                addDir(name,url1,2,'')
        if len(page)==1:
                for page in page:
                        nextp=int(page)+1
                        nextp=str(nextp)
                        url='http://tv-release.net/category/tvshows/tvxvid/'+'page/'+(nextp)+'/'
                        print 'URLURLURLURLURLURLURL================================='+str(url)
                        addDir('Next Page >>',url,7,'')
        
def TVSHOWSMP4(url):
        #html = net.http_GET(url).content
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        #req.add_header('Referer', str(iconimage))
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        html=str(link)
        match=re.compile('''style="text-align:left;">\n<a href="(.+?)".+?<font size="2px">(.+?)</font>''', re.DOTALL).findall(html)
        page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
        for url1, name in match:
                addDir(name,url1,2,'')
        if len(page)==1:
                for page in page:
                        nextp=int(page)+1
                        nextp=str(nextp)
                        url='http://tv-release.net/category/tvshows/tvmp4/'+'page/'+(nextp)+'/'
                        print 'URLURLURLURLURLURLURL================================='+str(url)
                        addDir('Next Page >>',url,8,'')

def TVSHOWS720(url):
        print 'TVSHOWS 720 URL========================================'+str(url)
        #html = net.http_GET(url).content
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        #req.add_header('Referer', str(iconimage))
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        html=str(link)
        match=re.compile('''style="text-align:left;">\n<a href="(.+?)".+?<font size="2px">(.+?)</font>''', re.DOTALL).findall(html)
        print (match)
        page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
        for url1, name in match:
                print (url1)
                addDir(name,url1,2,'')
        if len(page)==1:
                for page in page:
                        nextp=int(page)+1
                        nextp=str(nextp)
                        url='http://tv-release.net/category/tvshows/tv720p/'+'page/'+(nextp)+'/'
                        print 'URLURLURLURLURLURLURL================================='+str(url)
                        addDir('Next Page >>',url,9,'')

def TVSHOWS480(url):
        #html = net.http_GET(url).content
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        #req.add_header('Referer', str(iconimage))
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        html=str(link)
        match=re.compile('''style="text-align:left;">\n<a href="(.+?)".+?<font size="2px">(.+?)</font>''', re.DOTALL).findall(html)
        page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
        for url1, name in match:
                #print (match)
                addDir(name,url1,2,'')
        if len(page)==1:
                for page in page:
                        nextp=int(page)+1
                        nextp=str(nextp)
                        url='http://tv-release.net/category/tvshows/tv480p/'+'page/'+(nextp)+'/'
                        print 'URLURLURLURLURLURLURL================================='+str(url)
                        addDir('Next Page >>',url,10,'')

def SEARCH(url):
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Search TV-Release...XBMCHUB.COM')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search_entered = keyboard.getText().replace(' ','+')# sometimes you need to replace spaces with + or %20#
        if search_entered == None or len(search_entered)<1:
                CATEGORIES()
        else:
                url = 'http://tv-release.net/?s=%s&cat='%(search_entered).replace(' ','+')
                SEARCHNP(url)

def SEARCHNP(url):
        print 'searchnp=============================================='+str(url)
        url1=re.compile('s=(.+?)&cat').findall(str(url))
        for url1 in url1:
                #html = net.http_GET(url).content
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                #req.add_header('Referer', str(iconimage))
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                html=str(link)
                match=re.compile(r':left;">\n<a href="(.+?)/"><b>', re.DOTALL).findall(html)
                page=re.compile('''<!-- Zamango Pagebar 1.3 -->.+?<span class='zmg_pn_current'>(.+?)</span>''', re.DOTALL).findall(html)
                for search in match:
                        name=str(search).replace('http://tv-release.net','').replace('/','').replace('-',' ')
                        addDir(name,search,2,'')
                        if len(page)==1:
                                for page in page:
                                        nextp=int(page)+1
                                        nextp=str(nextp)
                                        url='http://tv-release.net/page/'+(nextp)+'/?s='+str(url1)+'&cat'
                                        print 'SEARCHNP URL1====================================='+str(url)
        addDir('Next Page >>',url,14,'')

def PLAYFILE(url):
        url=urlresolver.resolve(url)
        addLink('Play',str(url),'')




        #media_url=urlresolver.resolve(url)
        #xbmc.Player().play(media_url)
        #liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage='')
        #liz.setInfo( type="Video", infoLabels={ "Title": name } )
        #ok=xbmcplugin.player(handle=int(sys.argv[1]),url=media_url,listitem=liz)
        #return ok
        

                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        INDEX(url)
        
elif mode==2:
        print ""+url
        VIDEOLINKS(url,name)

elif mode==4:
        print ""+url
        MOVIESXVID(url)

elif mode==5:
        print ""+url
        MOVIES720(url)

elif mode==6:
        print ""+url
        MOVIES480(url)

elif mode==7:
        print ""+url
        TVSHOWSXVID(url)

elif mode==8:
        print ""+url
        TVSHOWSMP4(url)

elif mode==9:
        print ""+url
        TVSHOWS720(url)

elif mode==10:
        print ""+url
        TVSHOWS480(url)

elif mode==13:
        print ""+url
        SEARCH(url)

elif mode==14:
        print ""+url
        SEARCHNP(url)

elif mode==15:
        urlresolver.display_settings()

elif mode==16:
        print ""+url
        PLAYFILE(url)


        

xbmcplugin.endOfDirectory(int(sys.argv[1]))
